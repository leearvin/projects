from distutils.core import setup

setup(
    name='athletemodel',
    version='1.1.0',
    py_modules=['athletemodel'],
    author='hfpython',
    author_email='hfpython@headfirstlabs.com',
    url='http://www.headfirstlabs.com',
    description='A simple printer of athletemodel',
)
