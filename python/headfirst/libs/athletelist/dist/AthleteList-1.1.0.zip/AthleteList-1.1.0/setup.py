from distutils.core import setup

setup(
    name='AthleteList',
    version='1.1.0',
    py_modules=['AthleteList'],
    author='hfpython',
    author_email='hfpython@headfirstlabs.com',
    url='http://www.headfirstlabs.com',
    description='A simple printer of Athlete lists',
)
